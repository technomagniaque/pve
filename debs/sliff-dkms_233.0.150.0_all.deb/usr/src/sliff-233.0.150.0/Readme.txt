
1) Make sure you have installed linux kernel development package
2) Navigate to the driver directory
3) Execute "make"
4) Upon compilation, execute "insmod sliff.ko"
5) Make sure you have "/dev/sliff" created
6) Execute the application.
7) "Skipping BTF geenration for module" message is not really a fatal error and hence can be safely ignored.

NOTE : Please refer to the /niccli/Readme.txt in the SIT builds for more information on sliff driver.

