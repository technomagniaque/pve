                        =============
                        NICCLI README
                        =============

               Copyright (c) 2025 Broadcom Inc.
                      All rights reserved.
                      February 7th, 2025

Introduction
------------
The NICCLI configuration utility sets the nonvolatile configuration elements of the Broadcom
Ethernet network adapter, such as enabling or disabling RoCE, SR-IOV, and other options.
The NICCLI configuration utility can also perform firmware upgrades. The NICCLI configuration
utility uses the L2 driver in Linux, VMWare and FreeBSD and Windows. In UEFI environment, the
NICCLI configuration interacts with the PCIe hardware. The NICCLI configuration
utility supports both the BCM9574XX, BCM95750X, and BCM957608 family of devices.

SUPPORTED PLATFORMS:
--------------------
1. Linux :
    - x86_64
    - aarch64
2. Windows :
    - x86_64
3. ESXI 7/8 onwards
    - x86
    - x86_64
4. FreeBSD :
    - x86_64
5. UEFI :
    - x86_64
    - aarch64

Installing the NICCLI Configuration Utility
-------------------------------------------

This section provides information on installing/executing the NICCLI configuration Utility:

Installing the NICCLI Configuration Utility in Linux

    • Using NICCLI RPM:
        sudo rpm -i niccli -<version>.rpm

    • Using the NICCLI deb package:
        sudo dpkg –i niccli-<version>.deb

    Executing the NICCLI package in Linux

        • Users can execute the niccli binary by using the niccli-233.xxx-linux_<arch>.tar.gz package without
	  installing the rpms/deb packages. User has to unzip the file and execute the niccli.<arch> on the OS.

Executing the NICCLI Configuration Utility in Windows

    To install the NICCLI Configuration Utility, unzip the provided Windows package file and use the niccli.exe
    file to install it on Broadcom Ethernet Network interface cards.

Installing the NICCLI Configuration Utility in VMware

    To install the NICCLI Configuration Utility using a vib package:
        esxcli software vib install -v <VIB package> --no-sig-check

    NOTE:
        The vib packaging is under the process of VMware signing.

    To install the NICCLI Configuration Utility using a signed .zip bundle:
        esxcli software vib install -d <zip package>

Executing the NICCLI Configuration Utility in FreeBSD

    To install the NICCLI Configuration Utility, unzip the provided FreeBSD package file and use the niccli.freebsd
    file to install it on Broadcom Ethernet Network interface cards.

Executing the NICCLI Configuration Utility in UEFI

    To install the NICCLI Configuration Utility, unzip the provided uefi package file in uefi environment and use the niccli<arch>.efi
    file to install it on Broadcom Ethernet Network interface cards.

NICCLI Configuration Utility Usage and Commands
-----------------------------------------------
Provides information on PCI and operational inband communication using NICCLI.

The NICCLI Configuration Utility is a management tool that is used to perform operations on Broadcom Ethernet network
adapters. This utility provides support for PCI and operational inband communication. The utility also accepts arguments
to select the communication interface or the specified device in which to communicate from the device list.

NICCLI Configuration Utility Interface and Usage
================================================

The NICCLI configuration utilities provide three different types of interfaces. By default, the utility starts with the interactive
interface. The utility accepts three groups of command arguments based on the existing CLI standards.

<niccli> <HW i/f argument> [util arguments] [Target command]

NICCLI Configuration and Usage on VMWare 8.X
============================================

The following syntax is used when the signed bundle of NICCLI is installed:
esxcli niccli <command> -c <connection_type> -v <connection_type_value> [command options]
• -c : Indicates connection type connection_type : Value for connection type. Supported values are [dev|i|pci]
• -v : Indicates connection type value connection_type_value : Supported values are index_number, PF MAC Address
and PCI Address

Examples:
    1. esxcli niccli install -c i -v 1 -p=/BCM957414A4141DDLP.pkg
    2. esxcli niccli install -c dev -v 1 -p=/BCM957414A4141DDLP.pkg
    3. esxcli niccli install -c dev -v BC:97:E1:70:14:10 -p=/BCM957414A4141DDLP.pkg
    4. esxcli niccli install -c pci -v 0000:86:00.00 -p=/BCM957414A4141DDLP.pkg

Hardware Interface Group of Arguments
=====================================

The interface arguments depend on the hardware connection type and its specified depending arguments. The NICCLI
configuration utility supports the -pci interface which takes the PCI Bus/Device/Location of the device. Alternatively, the
utility also offers to list all the available Ethernet network adapter PCI devices in the system along with the appropriate
Ethernet/Network interface names.

• The NICCLI configuration utility has the -i/-dev index support which can select when more than one device is found
within the host.

NICCLI Configuration Utility Arguments
======================================

The utility arguments are optional. These are specific to the NICCLI configuration utility itself. E.g. convert all the output
into JSON or increase the logger verbosity, and so forth.

Target Command
==============

The target is nothing but the NICCLI configuration utility connected device. These targets offer a specific set of commands
depending on the connected interface/device. The target-specific commands are executed upon acquiring the connection
with the target.

NICCLI Configuration Utility Commands
=====================================

All the commands that are provided are case-sensitive and operate with any of the interface modes. The following rules
are for the newly defined NICCLI configuration utility syntax. The commands use a specific syntax as follows:

    • < > mandates user to specify the value
    • [ ] is an optional parameter.
    • Parameter syntaxes can also be combined such as [ -i <index value>] optional -i index argument but
      mandatory index value, if -i switch specified.
    • The NICCLI configuration utility provides "help" command with brief information for every command.
    • The NICCLI configuration utility shall accept combinations such as -h, -?, --help' to display the help.
    • Every command also has a detailed help description.
    • The NICCLI configuration utility also displays the supported commands and/or valid command syntax when the user
      executes an invalid command.

The NICCLI configuration supports the user command line argument as follows:

    ./niccli –i <index> <command line>
    ./niccli –pci <domain:bus:device.function> <command line>

NICCLI Configuration Utility Help

    To access the NICCLI configuration utility help, use the following command:
        ./niccli [--help | -h]

    Example:
        ./niccli -h

The utility provides three modes of execution:

    • Oneline Mode
        Execute the NICCLI configuration utility on a per-target command basis. In this mode, specify the hardware interface
        and target command with appropriate arguments. The NICCLI configuration utility connects to the target, executes
        the target command, and exits from the application. The return status of the command is the exit status of the NICCLI
        configuration utility.

        To list the available targets for Oneline mode use the following command:
            ./niccli --list

        Use the following command to display the list of available commands for Oneline Mode:
            ./niccli [-i <index of the target> | -pci <NIC pci address>] help

        Use the following command to display the help for a specific command:
            ./niccli [-i [<index of the target> | <mac addr> | <NIC pci address>]] help <command>

        Example:

            ./niccli -i 1 help nvm

    • Interactive Mode
        The NICCLI configuration utility starts in interactive console mode if no target command is provided. The interface starts
        with the target prompt upon a successful connection with the target.

            1) The NICCLI configuration utility provides a help command to list all the available or supported commands.
            2) The NICCLI configuration utility supports help [command] to display detailed help for the specific command.

        Upon execution of the given user command, the prompt is shown again for the next command.

        NOTE:
        This mode is best suited for connecting to the target and executing multiple operations/commands without
        having to disconnect from the target. This improves performance and time in establishing a connection with the
        target each time while executing a command. This is only for interactive usage and is not designed or meant for
        the scripting.

        To launch in Interactive Mode, use the following command:
            <NIC CLI executable> [-i <index of the target> | -pci <NIC pci address>]

        Use the following command to display the list of available commands for Interactive Mode:
        'help'

     • Batch Mode
        Write the list of commands into a flat text file and execute them in the NICCLI configuration utility without disconnecting.
        This combines Interactive and OneLine modes without disconnecting the target. If any one of the commands fails, the
        NICCLI configuration utility exits and shall not continue to execute the rest of the commands from the script.

        To launch in Batch Mode, use the following command:
            <NIC CLI executable> [-i <index of the target> | -pci <NIC pci address>] --batch <batch file>

        NOTE:
        Batch mode requires a flat text file with utility-supported commands. Supported commands can be listed using
        OneLine mode or Interactive mode. Upon failure of any commands, the utility exits without continuing with other
        commands.

NICCLI Logging
==============

1) 'scrutiny.ini' file captures the logs for the scrutiny library and to capture
the logs for the CLI layer alone, user has to specify any of the following
options in the cli command,

    A) niccli --verbose NULL <command>
       - Prints the verbose logs on the console.

    B) niccli --debug NULL <command>
       - Prints the debug logs on the console.

    C) niccli --verbose file.txt <command>
       - Redirects the verbose logs into the file specified.

    D) niccli --debug file.txt <command>
       - Redirects the debug logs into the file specified.

2) Running any niccli command with 'scrutiny.ini' file being present in the
same directory as niccli executable, will affect the overall completion time
for the command. This is because debug logging will get enabled when
'scrutiny.ini' file is present. It is recommended to used only for debugging purpose.

Enabling NICCLI Commands Autocompletion
========================================

1) User has to run "source /usr/share/bash-completion/completions/niccli-autocomplete" to enable the NICCLI command autocompletion.
2) User has to run "niccli <tab> <tab>" to see auto-completion commands.


KNOWN LIMITATIONS/ISSUES & USAGE GUIDELINES:
===========================================
    1) NICCLI framework does not support running multiple instances in parallel, sometimes it may lead to system
       crash and this scenario should be avoided.
    2) White space characters other than plain space like tab etc. are not supported as argument separators in the interactive mode.
    3) Interrupting niccli during the middle of some operations may result in unknown/undefined/unexpected behavior.
    4) DCB commands i.e. pfc, apptlv, up2tc, getqos, ets, listmap, dscp2prio and tcrlmt to work, user has disable the following nvm options "lldp_nearest_bridge",
       "lldp_nearest_non_tpmr_bridge" and "dcbx_mode".
    5) In FreeBSD for DCB commands to work, user has to make sure logical link of the interface should be UP. This is BSD layer2 driver (if_bnxt.ko) limitation.
    6) The error codes will be supported only for the online mode, the interactive mode and the batch mode will not have error codes displayed.
    7) If User encounters below error while running the niccli executable on Linux Systems, Please follow the below steps to avoid the below error:
        "/opt/niccli/niccli.x86_64: /lib/x86_64-linux-gnu/libnl-3.so.200: no version information available (required by /opt/niccli/niccli.x86_64)"
        A). Identify the libnl version installed on your Build Systems.
        B). Install 3.2.28 version of libnl3 (libnl3 and libnl-devel)
           a.    Source code can be found at below any one of the links
                    - https://www.infradead.org/~tgr/libnl/files/
                    - https://snapshot.debian.org/package/libnl3/3.2.21-1/
                    - https://snapshot.debian.org/package/libnl3/
                    - https://www.linuxfromscratch.org/blfs/view/7.10/basicnet/libnl.html
           b.    Untar the source code and run the below commands
                    - ./configure --prefix=/usr --sysconfdir=/etc --disable-static
                    - make
                    - make install.
           c.    Run export LD_LIBRARY_PATH=<installed library path>
                    - Check the make install logs for the location where the library is installed.
           d.    Then run the niccli
        C). If the user is fine with ignoring the “no version information available”, then they can skip #B.
    8) Unless -all option is explicitly specified, resmgmt command works based on it's default mode
        (for a selected single PF or for all PFs/entire NIC device) which is printed when it's
        executed or it's help is displayed. -all option performs the given command/operation
        for all the PFs of the given NIC device.
    9) NICCLI in the Linux secure boot environment displays the "Firmware Reset Counter" and
       "Error Recovery Counter" fields in the show command always as zero as the mmap fails due to security considerations.

    VMWARE LIMITATIONS:
    -------------------
    1) In interactive mode, editing the command by moving the cursor using the left/right arrow will not work. The user has to re-issue the command.

    2) Separate loggings makes the debugging easier for the developers.
       Since it supports Storage, switch, expanders, NIC products through different ways of communication interfaces,
       we cannot change the existing logging mechanism design/functionality alone for NIC.

    3) This design is well approved by all architects.

    4) Interactive mode will not be supported in niccli Plugin model.

    5) User has to provide an option "-s" (silent mode) for the command named "restorefactorydefaults" which require user confirmation 'Yes/No'.

    LINUX INBOX LIMITATIONS:
    -----------------------
    1) In Linux OS, When the secure boot is enabled the adapter configuration/query commands using niccli will not work as the
       mapping to the PCI BAR is not allowed by the OS.
    2) Running multiple instances of niccli at the same time can result in the unexpected outputs and command timeouts.
    3) In multihost environment, race conditions can occur if more than one host attempts to utilize the USHI channel at the
       same time and this can result in the corruption of the control and data registers, timeouts, etc.
    4) When the kernel configuration parameter CONFIG_IO_STRICT_DEVMEM=y is enabled and inbox bnxt_en driver is loaded, niccli
       adapter configuration/query commands will not work. This is because from the user space niccli cannot map the PCI BAR
       to access the hardware. Below are the two Work around's for this issue.
       A) Unbind the L2 driver from the PF.
       B) Enable the iomem=relaxed in the grub and reboot the server.
    5) niccli adapter configuration/query commands in the guest OS or VM can cause the unexpected outputs and command
       timeouts when the guest OS is loaded with the inbox bnxt_en driver and the PF is binded to the vfio-pci driver
       in the hypervisor and is attached to the guest OS or VM. In this case, guest OS or VM should be loaded with the out-of-box
       bnxt_en driver.
    6) The NICCLI command execution will be slow when inbox/upstream drivers are loaded.
    7) In case of writing/reading huge amounts of data from the hardware to user space, users might notice the considerable delay
       in the command completion when inbox/upstream drivers are loaded.


COMMANDS
--------
To get a current list of supported commands and the usage syntax supported by the
niccli utility, use the niccli help option.

$ niccli help

Commands sets - Generic/Offline
-------------------------------------------------------------------------------
list                      - Lists all the compatible devices
devid                     - Query Broadcom device id's.
pkgver                    - Display FW PKG version installed on the device.
verify                    - Verify FW packages & NVM
nvm-list                  - Display NVM components and its associated versions.
nvmview                   - View NVM directories data
list-eth                  - Lists all NIC devices with ethernet interface names
help                      - Lists the available commands
quit                      - Quits from the application

1) Supported Commands for BCM575xx and BCM576xx devices
-------------------------------------------------------------------------------
list                      - Lists all the compatible devices
devid                     - Query Broadcom device id's.
pkgver                    - Display FW PKG version installed on the device.
verify                    - Verify FW packages & NVM
nvmlist                   - Display NVM components and its associated versions.
nvmview                   - View NVM directories data
list-eth                  - Lists all NIC devices with ethernet interface names
help                      - Lists the available commands
quit                      - Quits from the application (Applicable in interactive mode only)
show                      - Shows NIC specific device information
txfir                     - Network Interface Card Transmission Finite
                            Impulse Response
pcie                      - Show/Execute pcie operation
nvm                       - NVRAM Option Management
backuppowercfg            - Backup Power Configuration
rfd                       - Restores NVM configuration to factory defaults
tsio                      - TSIO function capability on the pin
ingressqos                - Query and configure the ingressqos parameters
egressqos                 - Query and configure the egressqos parameters
reset                     - Reset the device
fw_sync                   - Synchronize primary & secondary FW images
livepatch                 - Query, Activate and Deactivate the patch in live
install                   - Install/Update FW
coredump                  - Retrieves coredump data from device.
snapdump                  - Retrieves snapdump data from device.
version                   - Display the current version of the application
vf                        - Configure and Query for a trusted VF
prbs_test                 - Run PRBS loopback test
serdes                    - Plots the serdes pci and ethernet eye and
                            prints the horizontal and vertical margin values.
loopback                  - Query/perform loopback config.
add_ntuple_filter         - Add ntuple flow filter.
free_ntuple_filter        - Free ntuple flow filter.
cfgtunnel                 - query/config custom tunnel port/rss.
write                     - Create or overwrite NVM data item with a file.
portstate                 - Query or configure the port state
clearcounters             - Clear the port counters
pfc                       - Configure the priority-based flow control
                            for a given priority.
apptlv                    - Configure the priority for the AppTLV
tcrlmt                    - Configure the rate limit for each traffic class
ets                       - Configure the enhanced transmission selection,
                            priority to traffic class and bandwidths.
up2tc                     - Configure the user priorities to traffic classes
getqos                    - Query the configured enhanced transmission selection,
                            priority to traffic class and bandwidths.
listmap                   - List the priority to traffic class and queueid mapping
dscp2prio                 - Query the dscp to priority mapping
peermemmap                - This command is used to configure the GPU host and
                            guest physical address mapping.
rxportrlmt                - Configure the receive side port rate limit
rxrlmt                    - Query the configured receive side rate control
                            parameters.
rxeprlmt                  - Configure the receive side rate control
                            parameters for a given endpoint.
txpartitionrlmt           - Query and Configure the transmit side partition
                            rate limit applies to traffic sent from a partition,
                            which is one PF and all of its child VFs.
txportrlmt                - Query and Configure the transmit side of
                            port rate limit.
txeprlmt                  - Query and Configure the PCIe endpoint
dutycycle                 - Set duty cycle on TSIO outgoing signal
dllsource                 - Set the DLL source for PHC
ptp                       - PTP extended parameters operation
msixmv                    - Display and configure the number of MSIX max
                            vectors values for VF's per each PF
synce                     - Configure the synchronous ethernet profile
pfalloc                   - Configure and Query for the number of PFs
                            per PCIe endpoint
read                      - Read the NVM item data and write its contents to a file.
dscdump                   - Retrieves dscdump for device

2) Supported Commands for BCM574xx device
-------------------------------------------------------------------------------
list                      - Lists all the compatible devices
devid                     - Query Broadcom device id's.
pkgver                    - Display FW PKG version installed on the device.
verify                    - Verify FW packages & NVM
nvmlist                   - Display NVM components and its associated versions.
nvmview                   - View NVM directories data
list-eth                  - Lists all NIC devices with ethernet interface names
help                      - Lists the available commands
quit                      - Quits from the application (Applicable in interactive mode only)
show                      - Shows NIC specific device information
txfir                     - Network Interface Card Transmission Finite
                            Impulse Response
pcie                      - Show/Execute pcie operation
nvm                       - NVRAM Option Management
backuppowercfg            - Backup Power Configuration
reset                     - Reset the device
tunnelcfg                 - Query and configure the custom tunnel configuration.
livepatch                 - Query, Activate and Deactivate the patch in live
install                   - Install/Update FW
coredump                  - Retrieves coredump data from device.
snapdump                  - Retrieves snapdump data from device.
version                   - Display the current version of the application
vf                        - Configure and Query for a trusted VF
prbs_test                 - Run PRBS loopback test
loopback                  - Query/perform loopback config.
add_ntuple_filter         - Add ntuple flow filter.
free_ntuple_filter        - Free ntuple flow filter.
cfgtunnel                 - query/config custom tunnel port/rss.
write                     - Create or overwrite NVM data item with a file.
pfc                       - Configure the priority-based flow control
                            for a given priority.
apptlv                    - Configure the priority for the AppTLV
tcrlmt                    - Configure the rate limit for each traffic class
ets                       - Configure the enhanced transmission selection,
                            priority to traffic class and bandwidths.
up2tc                     - Configure the user priorities to traffic classes
getqos                    - Query the configured enhanced transmission selection,
                            priority to traffic class and bandwidths.
listmap                   - List the priority to traffic class and queueid mapping
dscp2prio                 - Query the dscp to priority mapping
dllsource                 - Set the DLL source for PHC
ptp                       - PTP extended parameters operation
dscdump                   - Retrieves dscdump for device

Install commands
=================
The most common use of the niccli utility is the installation of a
Broadcom-supplied NVM package (a file usually ending in a '.pkg' extension
or suffix).

Syntax:
         niccli -i < target index> install [-force] [[-online] [-recovery/-rescue]] [.pkg_files]
         niccli -i < target index> install  [-force] | [-force][-online] | [-force][-recovery/-rescue] [package_files]
         niccli -i < target index> install [-options] [package_files] [-options]
         [-options] = [-force] | [-force][-online] | [-force][-recovery/-rescue]

         -rescue:  recover by disabling PCI ID check.

         -online: Fetch FW image online from Broadcom server & perform update.

         -recovery: Recovers the adapter and updates the package file.

         -force: Forces the installation of the package file .

         -y|--yes: Specify this option to answer 'yes' in prompt.

         -options should not appear among/in middle of the file list.

Example:
         niccli -i 3 install BCM957414A4141DDLP.pkg
	 niccli -i 3 install BCM957414A4141DDLP.pkg -online
	 niccli -i 3 install BCM957414A4141DDLP.pkg -force -recovery

list command
=============
Lists all the supported device information and can choose the target to connect with.

Syntax :
    niccli [-i <target index>] list

Example:
    niccli list

devid command
============
Display Broadcom device id information.

Syntax :
    niccli [-i <target index>] devid [-f <firmware package file(s)>]

Example:
    niccli -i 3 devid -f BCM957608-P2200GQF00.pkg

pkgver command
============
Display firmware package version installed on the device.

Syntax :
    niccli [-i <target index>] pkgver [-f <firmware package file(s)>]

Example:
    niccli -i 3 pkgver -f  BCM957608-P2200GQF00.pkg

nvm list command
=================
Display the NVM components and its associated version details

Syntax:
    niccli [-i <target index>] nvm-list [-v | -vv | -vvv ]>] [-f <firmware package file(s)>]
           [-v]/[-vv]/[-vvv]: Verbosity level depends on number of v's.
Example:
    niccli nvm-list -v

nvmview command
===============
To View the NVM item data
This command is not supported on UEFI platform.

Syntax:
     niccli [-i <target index>] nvmview [-type <NVM_directory_name [-v | -vv | -vvv ]>] [-f <package file>]
              -type: Input NVM directory name string.
                     -f: Input Firmware package file
Example:
    niccli nvmview -f BCM957608-P2200GQF00.pkg

verify command
==============
To inspect or verify the contents of a package file, you can use verify command
with one or more package filename arguments:

Syntax:
     niccli [-i <target index>] verify [-v | -vv | -vvv ]>] [-f <firmware package file(s)>]
              [-v]/[-vv]/[-vvv]: Verbosity level depends on number of v's.

Example:
    niccli verify -vv -f BCM957608-P2200GQF00.pkg

list-eth command
=================
Lists all the supported device information with ethernet interface name.
This command is not supported on UEFI platform.

Syntax:
     niccli [-i <target index>] list-eth

Example:
    niccli -i 3 list-eth

quit command
============
Quits the application.

Syntax:
     niccli [-i <target index>] quit

Example:
    niccli -i 3 quit

version command
===============
Display the current version of the application.

Syntax:
    niccli -i <target index> version

Example:
    niccli -i 4 version

Show command
============
This command will display all the basic details of the device

Syntax:

     show                 : Display the basic details of the device.

     show -all
          -all            : Display all the details of the device.

     show -livepatch
          -livepatch      : Display the livepatch supported target firmware versions
                            of the device.

     show -fwpackage [-f <firmware package>]|[-pkg <firmware package>]
          -fwpackage      : Display the package versions of the target firmware versions
                            of the device.
          -f              : Display the supported device ID's of the targeted firmware
                            package.
          -pkg            : Display the details of the targeted firmware package.

     show -certificate [-slot <slot number>]
          -certificate    : Display the imported certificate chain on the device.
                            This command is supported only on BCM9575xxx devices.
          -slot           : Slot number is where certificate chain on the device is imported.
                            The valid values are from 0 to 7. Default value is 0.

     show -nvmmeasurement
          -nvmmeasurement : Display whether the NVM configuration that is active in the system.
                            has been changed or not.
                            To facilitate this, a hash is generated based on nvm configuration.
                            The hash represents the measurement of the configuration.
                            This command is supported only on BCM9575xxx devices.

     show -ptpextended
          -ptpextended    : Display PTP extended parameters.
                            This command is supported only on BCM9575xxx devices.

     show -health
          -health         :  Display the device health.


Example :
     ./niccli -i 1 show
     ./niccli -i 1 show -all
     ./niccli -i 1 show -health
     ./niccli -i 1 show -certificate -slot 0
     ./niccli -i 1 show -fwpackage -f BCM957508-N2100G.pkg
     ./niccli -i 1 show -fwpackage -pkg BCM957508-N2100G.pkg

NVM Commands
============
niccli allows users to configure individual options in NVM and read option
information from the NVM.

1) NVM -getoption

   To read nvm option

   Syntax:
       niccli -i <target index> nvm -getoption [<option name> | <option name> -h] |
               [-scope <scope index>]

        -i: target index, is mandatory for NVM configuration commands.
	Note: In the case of multiple PF's, be the name of any of the PF interface names.
        This, however, does not remove the requirement for specifying the 'port index'
        parameter when retrieving a specific interface value, i.e. PF1's value, in the
        case of multiple interfaces.

        -getoption  : Get NVM configuration option of a device.
        option name : Specifies the nvm-option name to query.
        -scope      : The scope can be either of 'function' or 'port' index.


        niccli -i <target index> -getoption
        If only -getoption is given, help is displayed with listing of supported NVM
        option names.

        To get detailed help about an nvm option execute below command.
        niccli -i <target index> nvm -getoption <option name> -h

    Example:
        niccli -i 1 nvm -getoption
        niccli -i 5 nvm -getoption an_protocol -h
        niccli -i 5 nvm -getoption an_protocol -scope 0

2) NVM -setoption

    To configure nvm option

    Syntax:
        niccli -i <target index> nvm -setoption <optionname>
                     -value <value> [-scope <scope index>]

        -i: target index, is mandatory for NVM configuration commands.
	Note: In the case of multiple PF's, be the name of any of the PF interface names.
        This, however, does not remove the requirement for specifying the 'port index'
        parameter when retrieving a specific interface value, i.e. PF1's value, in the
        case of multiple interfaces.

        -setoption   : Set NVM configuration option of a device.
        option name  : specifies the nvm-option name to query.
        -scope       : The scope can be either of 'function' or 'port' index.
        -value       : The value for the specified option. Value can be in hex or decimal format

    Example:
        niccli -i 5 nvm -setoption an_protocol -scope 0 -value 1

3) NVM -saveoptions

    To save nvm options. saveoptions will save only the end user access NVM configuration options.

    Syntax:
        niccli -i <target index> -saveoptions -file <filename>

        -saveoptions : Save NVM configuration options on the device to a file.
        -file        : Input file name.

    Example:
        niccli -i 5 nvm -saveoptions -file output.txt

4) NVM -listoptions

    To display current and default nvm options

    Syntax:
        niccli -i <target index> -listoptions [-diff]

        -listoptions : Displays current and default NVM configuration options of a device.
        -diff        : Displays the difference between current and default NVM configuration
	               options of a device.

    Example:
        niccli -i 5 nvm -listoptions

Note:
======
1) If any NVM option is not supported on specific platform, user will see the failure messages
in the system log. Simultaneous NVM writes are not supported from niccli. If user still
tries to perform simultaneous NVM writes it may result timeout errors.

2) In Multi-Host/Multi-Root environment, get/set of nvm options for function/port level,
always query/configure the host1 (where host index starts from 1) nvm values. Other than host 1,
user cannot configure/query the nvm option values for the other available hosts.

cfgtunnel commands
==================
niccli allows users to query/configure custom tunnel destination port and
RSS(receive side scaling) information. This command is supported only on linux OS.

Syntax:
    Query port:
        niccli -i <target index> cfgtunnel vxlan_ipv4|vxlan_ipv6
    Free port:
	niccli -i <target index> cfgtunnel vxlan_ipv4|vxlan_ipv6 dst_port
    Set port:
	niccli -i <target index> cfgtunnel vxlan_ipv4|vxlan_ipv6 dst_port  <port num>
    Query RSS mode:
	niccli -i <target index> cfgtunnel rss_mode
    Configure RSS mode:
        niccli -i <target index> cfgtunnel rss_mode <inner/outer>

    Valid port range: 0-65535

Example:
    niccli -i 5 cfgtunnel vxlan_ipv4
    niccli -i 5 cfgtunnel rss_mode inner
    niccli -i 5 cfgtunnel vxlan_ipv4 dst_port 0

PCIe command
============
Allow users to fetch the PCIe statistics or counters.
This command is not supported on UEFI platform.

Syntax:
    niccli -i <target index> pcie -counters.
        -counters : pcie counters

Example:
    niccli -i 5 pcie -counters

Device Reset command
====================
Allow users to reset the device from the host.

Syntax:
     niccli -i <target index> reset
        Reset the device.

     niccli -i <target index> reset -cfa
        -cfa: Reset the OVS offload flows of the device.

     niccli -i <target index> reset -ap
        -ap: Reset management processor.

Example:
    niccli -i 5 reset
    niccli -i 5 reset -ap

Core Dump command
=================
Retrieves coredump from the device and from the ddr (if available). A <>.core
file will be generated in the same directory. And the .core file will be
generated from where the niccli utility is executed.

Syntax:
    niccli -i <target index> coredump [-ddr]

Note: It is strongly recommended not to use the "ethtool -W" command when using niccli
      "device_info" command to query the crashdump availability and "coredump" commands. User
      has to set the "ethtool -W" flag to previous state, if still user wants to go-ahead and
      use the "ethtool -W" command.

Example:
    niccli -i 3 coredump

Snap Dump command
=================
Retrieves snapdump from the device. The snapdump contains the firmware dump,
driver logs and cli logs. A *.core file will be generated from where the niccli utility
is executed. This command is not supported on UEFI platform.

Syntax:
    niccli -i <target index> snapdump

Example:
    niccli -i 3 snapdump

Trusted VF command
==================
Allow user to configure VF as a trusted entity and queries trusted VF configuration.
This command is only supported on Linux.

1) Command to configure trusted VF for a given vf_index

   Syntax:
        niccli -i <target index> vf -id <vf index> trust <enable/disable>

2) Command to query trusted VF configuration for a given vf_index

   Syntax:
        niccli -i <target index> vf -id <vf index> trust

Note: If kernel supports the trusted VF configuration in "ip link" command,
      It's strongly recommended for the user to configure it using "ip link"
      command. Otherwise inconsistent behaviour may be seen in the trusted
      VF configuration with kernel.

Example :
     niccli -i 1 vf -id 1 -trust enable
     niccli -i 1 vf -id 1 -trust

PRBS Test
=========
This command is used to configure and run PRBS test on a given port. The test can be run on a port or per lane
with a specific polynomial. This command will be used in port interface debug to analyze quality of link.
Supported prbs_modes are PRBS31/PRBS7/PRBS9/PRBS11/PRBS15/PRBS23/PRBS58/PRBS49/PRBS10/PRBS20/PRBS13 (Default PRBS31)
This command is supported on Linux OS and UEFI platform.

Note:
    1) The interface(s) should be fully initialized prior to the testing.
    2) During the testing, there should not be any queries or configs sent to the card.
       "ifdown" the interface(s) is recommended.

Syntax:
    niccli -i <target index> prbs_test <enable/disable>

    Above command will enable/disable PRBS test with default parameters i.e. prbs mode is PRBS31
    for all the RX/TX lanes.

    niccli -i <target index> prbs_test < -enable > [-mode <mode value> -rxlanemask <value> -txlanemask <value> [-duration <value in seconds>] [-tcode]]

    Above command will enable PRBS test with user specified prbs mode, RX/TX lanes and duration in seconds.

            -mode        : Specify the supported modes.
                           PRBS31/PRBS7/PRBS9/PRBS11/PRBS15/PRBS23/PRBS58/PRBS49/PRBS10/PRBS20/PRBS13 (Default PRBS31).
            -rxlanemask  : Receiver lane mask value.
            -txlanemask  : Transmitter lane mask value.
            -duration    : Duration to run the prbs test. Default time is 10 seconds
            -tcode       : If this option was provided. The prbs test will run on t-code project as well.

Example:
     niccli -i 4 prbs_test -enable
     niccli -i 4 prbs_test -disable
     Please use appropriate board specific parameters. Eg. For Thor2 board:
     prbs_test -enable -mode PRBS31 -rxlanemask 255 -txlanemask 255 -duration 10

Restore Factory Defaults
========================
Allow user to restore NVM configuration to factory defaults. This command is supported only on BCM9575xxx devices.
This command is not supported on UEFI platform.

Syntax:
    niccli -i <target index> rfd

Example:
    niccli -i 3 rfd

loopback
========
Allow user to configure different loopback modes i.e. phy loopback, mac loopback and external loopback
This command is supported only on Linux OS.

Syntax:
    1) niccli -i <target index> loopback phy_remote

       Above command enables loopback of local PHY RX to peer PHY TX. The packets transmitted by the
       peer are looped back to the peer at the PHY.No packets will reach the host. Host will see a link down.

    2) niccli -i <target index> loopback phy_local

       Above command enables a loopback of local TX to local RX at the PHY. Any packets transmitted
       from the host are looped back to the host. No packets will be transmitted on the line. If any
       peer is connected, the peer should ignore the link status from host.

    3) niccli -i <target index> loopback mac_local
       Above command enables a loopback of local TX to local RX at the MAC. Any packets transmitted
       from the host are looped back to the host.No packets will be transmitted on the line. If any peer
       is connected, the peer should ignore the link status  from host.

    4) niccli -i <target index> loopback external [RJ45]

       Above command prepares the PHY from external loopback and suppresses NONCE generation for auto
       negotiation to work with an external loopback. This option should only be used if the same
       port external loopback dongle or equivalent is used. Without this option and AN enabled, the host
       may not see a link up.

       NOTE : For RJ45 loopback option L2 driver should be loaded.
       loopback disable
       Above command disables any loopback setting.

    5) niccli -i <target index> loopback disable

       Above command disables any loopback setting.

    6) niccli -i <target index> loopback

       Above command is to query the configured loopback mode.

Example:
    niccli -i 4 loopback mac_local
    niccli -i 4 loopback disable

Ingressqos command
=================
This command is used to query and configure the QoS dynamically at receive
buffer thresholds by configuring different input parameters.
This command is not supported on UEFI platform.

Syntax:
     To get the ingress qos parameters
         niccli -i <target index> ingressqos -cosq -get [-persistent]
             -cosq        : This option is used to query the cosq parameter i.e. cosq state and the mode.
             -persistent  : This option is used to query the cosq configuration from the NVRAM.

     To set the ingress qos parameters
         niccli -i <target index> ingressqos -cosq -set -state <value> [-mode <value>] [-persistent]
             -cosq        : This option is used to set the cosq parameter i.e. cosq state and the mode.
             -state       : This is an optional parameter, and this field is a bitmask indicating which traffic classes
                            are enabled or disabled. Each bit represents a specific traffic class, where bit 0 represents
                            traffic class 0 and bit 7 represents traffic class 7. A value of 0 indicates that the
                            traffic class is not enabled. A value of 1 indicates that the traffic class is enabled.
             -mode        : This is an optional parameter, and this field is a bitmask indicating which traffic class
                            are lossy or lossless. Each bit represents a specific traffic class where bit 0 represents
                            traffic class 0 and bit 7 represents traffic class 7. A value of 0 indicates that the
                            traffic class is lossy. A value of 1 indicates that the traffic class is lossless.
             -persistent  : If the persistent option is given the configuration is written to NVRAM to save the
                            configuration across the reboots.

Example:
     niccli -i 5 ingressqos -cosq -get
     niccli -i 5 ingressqos -cosq -set -state 255 -mode 16
     In the above example, all the 8 traffic classes are enabled and mode lossless(1) is configured on traffic class 4.

Egressqos command
=================
This command is used to query and configure the QoS dynamically at transmit
buffer thresholds by configuring different input parameters.
This command is not supported on UEFI platform.

Syntax:
     To get the egress qos parameters
         niccli -i <target index> egressqos -cosq -get [-persistent]
             -cosq        : This option is used to query the cosq parameter i.e. cosq state and the mode.
             -persistent  : This option is used to query the cosq configuration from the NVRAM.

     To set the egress qos parameters
         niccli -i <target index> egressqos -cosq -set -state <value> [-persistent]
             -cosq        : This option is used to set the cosq parameter i.e. cosq state and the mode.
             -state       : This field is a bitmask indicating which traffic classes are enabled or disabled.
                            Each bit represents a specific traffic class where bit 0 represents traffic class 0 and bit 7
                            represents traffic class 7. A value of 0 indicates that the traffic class is not enabled.
                            A value of 1 indicates that the traffic class is enabled.
             -persistent  : If the persistent option is given the configuration is written to NVRAM to save the
                            configuration across the reboots.
Example:
     niccli -i 6 egressqos -cosq -get
     niccli -i 6 egressqos -cosq -set -state 255
     In the above example, all the 8 queues are enabled.

Serdes command
==============
This command is used to plot the serdes ethernet eye, PCI eye scope and margin values of the eye.
This command is supported only on Linux OS.

Syntax:
     To plot the serdes ethernet eye and the test results.
         niccli -i <target index> serdes -ethernet [-plot]
             -ethernet   : This option is used to plot the serdes ethernet eye.
                           By default this options displays only horizontal and
                           vertical margin values, including the test result.
             -plot       : This is an optional parameter. When user specifies this option, will plot the eye and
                           displays the horizontal and vertical margin values, including the test result.

   Note:
     1. While plotting the serdes ethernet eye the link toggling is expected.
     2. Serdes ethernet and pci eye shares the resources of the NIC. Therefore, these commands
        cannot be run concurrently. If pci eye is running and you attempt to run ethernet eye
        tool will return failure.

     To plot the serdes pci eye and the test results.
         niccli -i <target index> serdes -pci -lane <pci lane number> [-plot] [-targetber <value>]
             -pci        : This option is used to plot the serdes pci eye.
             -lane       : This option is used to specify the pci lane number.
             -plot       : This is an optional parameter. When user specifies this option, will plot the eye and
                           displays the horizontal and vertical margin values, including the test result.
             -targetber  : This option is used to specify the target bit error rate. By default serdes pci eye
                           is plotted with BER "1e-8". This option is only supported on BCM9575xxx and above devices.
                           The supported target BER values are "1e-8", "1e-9", "1e-10" and "1e-11"

     To stop the running serdes pci eye scope.
         niccli -i <target index> serdes -pci -stop
             -stop       : This option is used to stop the running serdes pci eye plotting.
                           This option is only supported on BCM9575xxx and above devices.
Example :
     niccli -i 3 serdes -ethernet
     niccli -i 3 serdes -ethernet -plot
     niccli -i 6 serdes -pci -lane 0
     niccli -i 6 serdes -pci -lane 0 -plot
     niccli -i 6 serdes -pci -lane 0 -plot -targetber 1e-10
     niccli -i 6 serdes -pci -stop

Ntuple commands
===============
These commands are supported only on linux OS.

1) add_ntuple_filter
       Below command is used to add ntuple flow filter for the specified MAC and destination port

       Syntax:
           niccli -i <target index> add_ntuple_filter <MAC> <dest_port> <dst_port_mask> <VF_id> <ip_type>

            MAC            : MAC address in format xx:xx:xx:xx:xx:xx
            dst_port       : destination port
            dst_port_mask  : destination port mask
            vf_id          : VF ID
            ip_type        : IP type: 1 - IPV4, 2 - IPV6, 3 - ARP-REPLY

       Example:
           niccli -i 4 add_ntuple_filter 00:01:02:03:04:a3 1023 0xFFFF 0 1

2) free_ntuple_filter
       Below command is used to free ntuple flow filter for the specified filter id

       Syntax:
           niccli -i <target index> free_ntuple_filter <filter_id in hex>

            filter_id:  ID to filter ntuple filter

       Example:
           niccli -i 4 free_ntuple_filter 0xAFFF

Backup Power Operations
=======================
This command gets the current settings of the NIC Backup Power Configuration.
This command is not supported on UEFI platform.

Syntax:
    niccli -i <target index> backuppowercfg

Example:
    niccli -i 4 backuppowercfg

PFC command
============
This command is used to enable priority-based flow control on a given priority.
This command is supported only on linux OS.

Syntax:
     niccli -i <target index> pfc -enable <pfc list>
     The valid range is from 0 to 7. Where list is a comma-separated value for each pfc.
     To disable the pfc, user needs to provide a value of 0xFF.

Example:
     niccli -i 5 pfc -enable 5,6
     niccli -i 5 pfc -enable 0xFF
     Where example #1 will enable the pfc on priority 5 and 6.

AppTLV command
==============
This command is used to configure the priority of the AppTLV
This command is supported only on linux OS.

Syntax:
     niccli -i <target index> apptlv -add -app <priority,selector,protocol>
     niccli -i <target index> apptlv -del -app <priority,selector,protocol>

Example:
     niccli -i 4 apptlv -add -app 5,1,35093
     niccli -i 4 apptlv -del -app 5,1,35093

Ratelimit command
=================
1) tcrlmt command
     Below command is used to set the rate limit for each traffic class in units of percentage (%).
     This command is supported only on linux OS.

     Syntax:
         niccli -i <target index> tcrlmt -set -r <list of rate limit>
            Where list is a comma-seperated percentage limit for each TC.

     Example:
         niccli -i 1 tcrlmt -set -r 10,20,30
         niccli -i 1 tcrlmt -set -r 10
              Where example #1 will limit TC0 to 10%, and TC1,TC2 to 20% and 30% each.

Note: User has to provide all the tc's ratelimit values, when 8 tc's are configured.

2) rxrlmt command
     Below command is used for user to query the receive side rate limits
     This command is supported only on linux OS and FreeBSD OS.

     Syntax:
         niccli -i <target index> rxrlmt -get [-persistent]
             -persistent : To read the configuration from the NVRAM.

     Example:
         niccli -i 1 rxrlmt -get

Enhanced transmission selection command
=======================================
This command is used to configure the enhanced transmission selection,
priority to traffic class and traffic class bandwidths.
This command is supported only on linux OS.

Syntax:
     niccli -i <target index> ets -tsa <tc[0-7]:[ets|strict], ...> -up2tc <priority[0-7]:tc>, ...> -tcbw <list>
         -tsa   : Transmission selection algorithm, sets a comma separated list of traffic classes to
                  the corresponding selection algorithm. Valid algorithms include "ets" and "strict".

         -up2tc : Comma separated list mapping user priorities to traffic classes.

         -tcbw  : Comma separated list of bandwidths for each traffic class the first value
                  being assigned to traffic class 0 and the second to traffic class 1 and so on.

Example :
   niccli -i 1 ets -tsa 0:ets,1:ets,2:strict,3:strict,4:strict,5:strict,6:strict,7:strict
                -up2tc 0:0,1:0,2:0,3:0,4:0,5:1,6:0,7:0 -tcbw 70,30

Up2tc command
=============
This command is used to set the user priorities to traffic classes.
This command is supported only on linux OS.

Syntax:
     niccli -i <target index> up2tc -p <priority[0-7]:tc>, ...>
         -p : Comma separated list mapping user priorities to traffic classes.

Example:
     niccli -i <target index> up2tc -p 0:0,1:0,2:0,3:0,4:0,5:1,6:0,7:0

Getqos command
==============
This command is used to get the configured enhanced transmission selection,
priority to traffic class, traffic class bandwidths and the list of configured
application tlvs.This command is supported only on linux OS.

Syntax:
    niccli -i <target index> getqos

Example:
     niccli -i 4 getqos

Listmap command
===============
This command is used to list the priority to traffic class mapping
and related queue id for a given physical function.
This command is supported only on linux OS.

Syntax:
     niccli -i <target index> listmap -pri2cos

Example:
     niccli -i 4 listmap -pri2cos

Dscp2prio command
=================
This command is used to query the dscp to priority mapping.
This command is supported only on linux OS.

Syntax:
    niccli -i <target index> dscp2prio

Example:
     niccli -i 4 dscp2prio

Peermemmap command
====================
This command is used to configure the GPU host and guest physical address mapping
This command is supported only on Linux OS.

Syntax:
     niccli -i <target index> peermemmap -hpa <list of values> -gpa <list of values> -size <list of values>
             -hpa   : This option is used to specify the list of host physical addresses.
                      Max 8 entries are supported. User has to provide the list with a
                      comma seperated for each host physical address. The value should be
                      in the hex-decimal.
             -GPA   : This option is used to specify the list of guest physical addresses.
                      Max 8 entries are supported. User has to provide the list with a
                      comma seperated for each guest physical address. The value should be
                      in the hex-decimal.
             -size  : This option is a comma separated list in kilobytes for each mapping.
                      Max 8 entries are supported. The value should be in the hex-decimal.

Example:
     niccli -i 3 peermemmap -hpa 0x1FFFFFFF,0x2FFFFFFF,0x3FFFFFFF,0x4FFFFFFF
     -gpa 0x9FFFFFFF,0xAFFFFFFF,0xBFFFFFFF,0xCFFFFFFF,0xDFFFFFFF
     -size 0x10000,0x10000,0x8000,0x8000

Rxportrlmt command
=================
The user can configure receive rate control that applies to all traffic in a receive
CoS queue group. A queue group has one queue for each traffic class. When the NIC queues
received packets according to the packet’s destination, there is a queue group per PCIe
endpoint and this rate limit shapes traffic to the endpoint. When the NIC queues receives
packets according to the receive panel port, there is a queue group per port, and this rate
limit shapes all traffic received on one port. Only a maximum rate may be configured.

This command is supported only on Linux OS and FreeBSD OS.

Syntax:
     niccli -i <target index> rxportrlmt -set -max <value> [-persistent]
             -max        : The max option specifies an 8-bit rate limit as a percentage of total link
                           bandwidth, with a range of 0 to 100 percent. A value of 0 indicates no rate
                           limit, and deletes a previously configured rate limit.
             -persistent : If the persistent option is given the configuration is written to NVRAM, but
                           it does not take effect immediately.
Example:
     niccli -i 4 rxportrlmt -set -max 5

Rxeprlmt command
================
The user can configure receive rate control that applies to all traffic in a receive CoS queue group.
A queue group has one queue for each traffic class. When the NIC queues received packets according to
the packet’s destination, there is a queue group per PCIe endpoint and this rate limit shapes traffic
to the endpoint. When the NIC queues receives packets according to the receive panel port, there is a
queue group per port, and this rate limit shapes all traffic received on one port. Only a maximum rate
may be configured; configuration of a minimum guaranteed rate is not supported.

For multi-host or multi-root, the syntax is as follows. The command specifies the endpoint index explicitly,
so that a user can specify the endpoint rate limit for all endpoints from one host.
On 4-endpoint systems, ep is 0 to 3. On 2-endpoint systems, ep is 0 or 2

The max option specifies an 8-bit rate limit as a percentage of total link bandwidth, with a range of 0 to 100 percent.
A value of 0 indicates no rate limit, and deletes a previously configured rate limit.

When the NIC queues packets according to a packet’s destination (as it does for multi-host or multi-root), the firmware
automatically computes an endpoint rate limit as a percentage of the endpoint’s PCIe bandwidth. The configured rate
limit takes effect if it is less than the automatic rate limit.

The configuration takes effect immediately. The change is not stored in NVRAM. However, if the persistent option is given,
the configuration is written to NVRAM, but it does not take effect.

This command is supported only on Linux OS and FreeBSD OS.

Syntax:
     niccli -i <target index> rxeprlmt -set -ep0_max <value> [-ep1_max <value>] [-ep2_max <value>] [-ep3_max <value>] [-persistent]
         -ep0_max    : Endpoint 0 max rate limit
         -ep1_max    : Endpoint 1 max rate limit
         -ep2_max    : Endpoint 2 max rate limit
         -ep3_max    : Endpoint 3 max rate limit
         -persistent : If the persistent option is given the configuration is written to NVRAM, but
                       it does not take effect immediately.
Example:
     niccli -i 4 rxeprlmt -set -ep0_max 0

Txpartitionrlmt command
=======================
This command is used to control the partition rate control applies to traffic
sent from a partition, which is one PF and all of its child VFs.

Each rate limit is specified as a percentage of link bandwidth. The firmware automatically
adjusts the rate limits when link speed changes. Only a maximum rate can be configured.
Configuration of a minimum guaranteed rate is not supported.

By default, the command updates the running configuration. The change is not stored in NVRAM.
The persistent option indicates that the configuration is written to NVRAM, but it does not take
effect immediately. The change may be activated by resetting the firmware or rebooting the host
or power cycling the system.

The valid range for max rate is an integer, from 0 to 100. A value of 0 signifies
no rate limit, in which case the firmware deletes any previous rate limit.
By default, the firmware does not enforce a maximum rate.

This command may be configured for a PF regardless of the number of PFs associated with
a port, even if there is only one partition. This feature assumes the number of partitions
is established when firmware initializes and cannot be changed without restarting the firmware.

This command is supported only on Linux OS and FreeBSD OS.

Syntax:
    To set the tx partition rate limit
       niccli -i <target index> txpartitionrlmt -set -max <value> [ -persistent ].
             -max        : The max option specifies the maximum aggregate rate at which the PF
                           and its child VFs can transmit. The sum of the max rate limits for all
                           partitions on a port may exceed the link bandwidth.
             -persistent : This option is used to save the partition rate limit configuration across reboots.

     To get the tx partition rate limit
        niccli -i <target index> txpartitionrlmt -get [ -persistent ]
             -persistent : This option is used to query the partition rate limit from the NVRAM.
Example:
    niccli -i 3 txpartitionrlmt -get
    niccli -i 3 txpartitionrlmt -set -max 2

Txportrlmt command
==================
This command is used to control the transmit side port rate limit.
This command is supported only on Linux OS and FreeBSD OS.

   Syntax:
     To set the tx port rate limit
        niccli -i <target index> txportrlmt -set -max <value>
             -max        : The max option specifies the maximum port rate limit value. And the value
                           should be in the units of Mbps. If user wants to cancel the transmit port
                           rate limit, user has to provide the value Zero(0).

     To get the tx port rate limit
         niccli -i <target index> txportrlmt -get

   Example:
       niccli -i 6 txportrlmt -get

Txeprlmt command
================
The command is used to query and configure the PCIe endpoint transmit rate control
This command is supported only on Linux OS and FreeBSD OS.

   Syntax:
     To set the tx PCIe EndPoint rate limit
       niccli -i <target index> txeprlmt -set -p <port number> -ep0_max <value> [-ep1_max <value>] [-ep2_max <value> [-ep3_max <value>] [-persistent]
         -p          : Specifies the index of external port of the device
         -ep0_max    : Endpoint 0 max rate limit
         -ep1_max    : Endpoint 1 max rate limit
         -ep2_max    : Endpoint 2 max rate limit
         -ep3_max    : Endpoint 3 max rate limit
         -persistent : If the persistent option is given the configuration is written to NVRAM, but
                       it does not take effect immediately.

     To get the tx PCIe EndPoint rate limit
        niccli -i <target index> txeprlmt -get -p <port number> [-persistent]

   Example:
     1) On a 1-port NIC (port number of 0 is implied) with two endpoints, allow each endpoint to use
        up to 50% of the transmit bandwidth.

        niccli -i 3 txeprlmt -set -p 0 -ep0_max=50 -ep2_max=50

     2) On a 2-port NIC with two endpoints, allow the CPU attached to EP 0 to use up to 60% of each link,
        and allow the CPU attached to EP 2 to use up to 40% of each link.

        niccli -i 1 txeprlmt -set -p 0 -ep0_max=60 -ep2_max=40
        niccli -i 1 txeprlmt -set -p 1 -ep0_max=60 -ep2_max=40

   An endpoint rate limit only has an effect when set below the endpoint’s effective PCIe bandwidth.

   The -p option specifies the index of an external port. The range is 0 to one less than the number of
   external ports on the NIC.

   The user may specify rate limits for one or more endpoints on the port. Of course, rate limits can only
   be specified for endpoints that exist on the system. Only a maximum rate can be configured.
   Configuration of a minimum guaranteed rate is not supported.

   The max option specifies the maximum aggregate transmit rate of traffic from all functions on the endpoint.
   It is specified as a percentage of the bandwidth of the specified port. The command accepts integer values
   from 0 to 100. A value of 0 indicates no maximum rate limit.

   By default, this command updates the running configuration. The change is not stored in NVRAM. The persistent
   option indicates that the configuration is written to NVRAM, but it does not take effect immediately.
   The change may be activated by resetting the firmware or rebooting the host or power cycling the system.

DSC Dump command
=================
This command is used  to retrieves DSC dump data from a device. A <xxx>.dmp file will be
generated in the same directory where niccli executable is running.
This command is supported on Linux OS, VMWare OS and FreeBSD OS.

Note: While the dscdump operation is running, FW does not service other
commands that operate on the PHY. System logs may indicate command timeouts
while the dscdump operation is in progress.

Syntax:
    niccli -i <target index> dscdump <lane_number> [<diag_level>]

Above DSC dump command takes the following parameters as a input.

    lane_number : MRS lane number. To collect the dsc dump on all the supported lanes, please provide a value of 65535.
                  DSC dump on all lanes is supported only on BCM9576xx devices.
    diag_level  : This is an optional parameter. If the user does not specify this parameter
                  by default DSC dump will be collected on all the supported diag levels.
                  Supported diag levels are as follows
                             0 = diag lane
                             1 = diag core
                             2 = diag event
                             3 = diag eye
                             4 = diag reg core
                             5 = diag reg lane
                             6 = diag uc core
                             7 = diag uc lane
                             8 = diag lane debug
                             9 = diag ber vert
                             10 = diag ber horz
                             11 = diag event safe
                             12 = diag timestamp

Example:
    niccli -i 4 dscdump -lane 65535 -diaglevel 2

FW sync command
===============
This command can be used to synchronize SBI, SRT and CRT Primary and Secondary FW images. This command is supported only
on BCM9575xx and BCM9576xxx devices.

Syntax:
    niccli -i <target index> fw_sync

Example:
    niccli -i 3 fw_sync

TX FIR Settings
===============
This command is used to query and configure the transmit side finite impulse response operations.
This command is not supported on UEFI platform.

1) Below command is used to query TxFIR settings.

    Syntax:
        niccli -i <target index> -get -modtype <mod type> -lane <lane number>

        -modtype        : Modulation types of TxFIR. Supported values are 'NRZ','PAM4','C2MNRZ','C2MPAM4','PAM4-112','C2MPAM4-112G' and
                          'LPOPAM4-112G' of the device. The modulation types 'PAM4-112','C2MPAM4-112G' and 'LPOPAM4-112G' are only supported
                          on BCM5760x devices. The modulation types 'PAM4' and 'C2MPAM4' are supported on BCM5750x and BCM5760x devices.
        -lane           : MRS lane number

2) Below command is used to configure the TxFIR settings.

    Syntax:
        niccli -i <target index> -set -modtype <mod type> -lane <lane mask> -pre1 <value> -pre2 <value> [-pre3 <value>] -main <value>
	    -post1 <value> -post2 <value> [-post3 <value> -nlcl <value> -nlcu <value>]

        -modtype        : Modulation types of TxFIR. Supported values are 'NRZ','PAM4','C2MNRZ','C2MPAM4','PAM4-112','C2MPAM4-112G' and
                          'LPOPAM4-112G' of the device. The modulation types 'PAM4-112','C2MPAM4-112G' and 'LPOPAM4-112G' are only supported
                          on BCM5760x devices. The modulation types 'PAM4' and 'C2MPAM4' are supported on BCM5750x and BCM5760x devices.

        -lane           : The lane mask of the TxFIR to be configured.

Note:
    The following params '-pre1', '-pre2', '-main', '-post1', '-post2' are the mandatory parameters for all the modulation types.
    Where as '-pre3', '-post3', '-amp', '-nlcl' and '-nlcu' are the optional parameters, which are required only for particular
    modulation type. The valid range for parameter '-nlcu' is from -100 to 100. The valid value for parameter '-nlcl' is -1 and
    the valid range for other parameters is from -32768 to 32767.

    Below is the list of supported parameters for each modulation type:
        1) LPOPAM4-112G         : '-pre1', '-pre2', '-pre3', '-post1', '-post2', '-main', '-nlcl' and '-nlcu'
        2) NRZ, PAM4 and C2MNRZ : '-pre1', '-pre2', '-post1', '-post2', '-post3', '-main' and '-amp'
        3) PAM4-112, C2MPAM4 and C2MPAM4-112G : '-pre1', '-pre2', '-pre3', '-post1', '-post2', '-main' and '-amp'

Examples :
     niccli -i 3 txfir -set -modtype LPOPAM4-112G -lane 1 -pre1 1 -pre2 -2 -pre3 10 -main 12 -post1 -10 -post2 15 -nlcl -1 -nlcu 1
     niccli -i 3 txfir -get -modtype LPOPAM4-112G -lane 0

     niccli -i 4 txfir -set -modtype PAM4 -lane 1 -pre1 1 -pre2 -2 -main 12 -amp 10 -post1 -10 -post2 15 -post3 10
     niccli -i 4 txfir -get -modtype PAM4 -lane 0

     niccli -i 1 txfir -set -modtype NRZ -lane 1 -pre1 1 -pre2 -2 -main 12 -amp 10 -post1 -10 -post2 15 -post3 10
     niccli -i 1 txfir -get -modtype NRZ -lane 0

     niccli -i 1 txfir -set -modtype PAM4-112 -lane 1 -pre1 1 -pre2 -2 -pre3 5 -main 12 -amp 10 -post1 -10 -post2 15
     niccli -i 1 txfir -get -modtype PAM4-112 -lane 0


PF Alloc
=========

To query and configure the number of PFs per PCIe endpoint.
This command is supported only on devices BCM9575xxx and above.
This command is supported on Linux OS, Windows OS and FreeBSD OS.

Syntax:
    Below command is used to query the number of PF's for all the endpoints.
       niccli -i <target index> pfalloc -get

    Below command is used to configure number of PF's for each endpoint.
        niccli -i <target index> pfalloc -set <ep0_pf_cnt> <ep1_pf_cnt> <ep2_pf_cnt> <ep3_pf_cnt>
            <ep0_pf_cnt>: number of PF to be written on EP0
            <ep1_pf_cnt>: number of PF to be written on EP1
            <ep2_pf_cnt>: number of PF to be written on EP2
            <ep3_pf_cnt>: number of PF to be written on EP3

     NOTE: 1) The number of non-zero values can be for 2 endpoints or 4 endpoints.
           2) The sum of all the endpoints should be less than or equal to 16.

Example :
     niccli -i 5 pfalloc -get
     niccli -i 5 pfalloc -set 0 0 0 0

MSIX Max Vectors
================

To query and configure the number of msix max vectors values for VF's per each PF.
This command is supported only on devices BCM9575xxx and above.
This command is supported only on Linux OS and Windows OS.

Syntax:

Below command is used to query the msix max vector table.
   niccli -i <target index> msixmv -get [-all | -pf <pf_number>]

    -pf   : PF Number to query the table of 8 rows for msix max vectors.
    -get  : Get the msix max vectors for PF.
    -all  : Displays msix max vectors for all the PF's.

Below command is used to configure the msix ma vector table.
    niccli -i <target index> msixmv -set [-pf <PF number>]

    -pf   : PF Number to query the table of 8 rows for msix max vectors.
    -set  : Confiure the msix max vectors for PF.

Example :
     niccli -i 3 msixmv -get -pf 0
     niccli -i 3 msixmv -get -all
     niccli -i 3 msixmv -set -pf 0

LivePatch
=========

To query, activate and deactivate the live patch from NVM.

Syntax:
  Below commands are used to activate or deactivate the live patch from NVM.
    niccli -i <target index> livepatch activate [target_fw]
    niccli -i <target index> livepatch deactivate [target_fw]
           target_fw=common_fw/secure_fw

    target_fw : Target firmware is an optional parameter to active/deactivate the livepatch.
                By default tool updates all the supported target firmwares. target_fw strings
                are "common_fw" or "secure_fw" are supported on BCM95750x devices.
                "chimp_fw" string is supported on BCM9574x devices.

  Below command is used to query the livepatch supported target firmware versions.
    niccli -i <target index> livepatch

  Below command is used to update the patch file directly to the device i.e. without installing it on NVM.
    niccli -i <target index> livepatch update [target_fw] <patch_file>


Example:
   niccli -i 3 livepatch activate

TSIO Function PIN
=================
This command is used to enable/disable a TSIO function and set a function capability on the pin.
This command is not supported on UEFI platform.

Syntax:
  niccli -i <target index> tsio -pin <pin_index> -pu <pin usage string> [enable/disable]
    -pin     : Pin Index.
               Valid Index : 0 to 3
    -pu      : Pin usage string.
               Supported strings : none | pps_in | pps_out | sync_in | sync_out | synce_primary_clock_out | synce_secondary_clock_out
    -enable  : Enable function capability on the pin.
    -disable : Disable function capability on the pin.

Example :
  niccli -i 5 tsio
  niccli -i 5 tsio -pin 0 -pu none -enable
  niccli -i 5 tsio -pin 1 -pu pps_in -disable

Duty Cycle on TSIO
==================
This command is used to set duty cycle on TSIO outgoing signal.
This command is supported only on Linux OS and VMWare OS.

Syntax:
   niccli -i <target index> dutycycle -period <value> -up <value>
      value : Given value will treated as in nanoseconds.
              And the period value should be larger than "up" value.

Example:
     dutycycle -period 1 -up 0

DLL Source for PHC
==================
This command is used to set the DLL source for PHC.
This command is supported only on Linux OS and VMWare OS.

Syntax:
   niccli -i <target index> dllsource -source <value> -frequency <value>
      -source      :  The valid values range is 0 to 4. .
      -frequency   :  The valid values range is 0 to 3

Example :
     niccli -i 3 dllsource -source 1 -frequency 1

Read and Write
==============
Below command reads the NVM item data and write its contents to a file.
This command is not supported in UEFI platform.
Syntax:
    niccli -i <target index> read -type <NVM_directory_name> -f <filename>
              -type: Input NVM directory name string
                 -f: Input file name
Example:
    niccli -i 3 read -type vpd -f output.txt

Below command creates or overwrites NVM data item with a file. This
command is supported only on Linux OS.
Syntax :
     niccli -i <target index> write -f <filename> -type <NVM_directory_name>
              -type: Input NVM directory name string
                 -f: Input file name
Example:
    niccli -i 3 write -type vpd -f output.txt

PTP Extended Commands
=====================
To Get/SET the PTP extended parameters.
This command is supported only on Linux OS and VMWare OS.

Below command is used to get the PTP extended parameters.

  niccli -i <target index> ptp -get

Below command is used to set the primary/secondary function as well as set the failover parameters. All the parameters are optional.

  niccli -i <target index> -set [-ppf <pri pfid>] [-pvf <pri vfid>] [-spf <sec pfid>] [-svf <sec vfid>]
              [-m <phc mode>] [-t <timer value>]

     -ppf: primary physical function ID
               -pvf: primary virtual function ID belongs to primary PF ID
               -spf: secondary physical function ID
               -svf: secondary virtual function ID belongs to secondary PF ID
               -t:   failover timeout value in hex
               -m:   Supported modes are "switch", "all", "pf_only".

Example:
   niccli -i 3 ptp -get
   niccli -i 3 ptp -set -ppf 2

Synchronous Ethernet (SyncE) commands
=====================================
Synchronous Ethernet (SyncE) specifies the transference of clock/frequency over the ethernet physical layer, which is also
known as physical layer timing. It is an extension to the Ethernet network to carry frequency as well as clock traceability
for the whole network. The frequency from SyncE usually is called a recovered clock and it is used as input to PLL providing
clocks for Ethernet. This command is supported only on BCM9575xxx devices.This command is supported only on Linux OS.


Syntax:
  Below command is used to set the SyncE frequency profile, primary and secondary clock state.

     niccli -i <target index> synce -set -freq <value> [-pclk <value>] [-sclk <value>]

       -set      : Specifies the transference of clock or frequency over the ethernet
                   physical layer, which is also known as physical layer timing.
                   It is an extension to the Ethernet network to carry frequency
                   as well as clock traceability for the whole network.
                   The frequency from SyncE usually is called a recovered clock
                   and it is used as input to PLL providing clocks for Ethernet.
       -freq     : Frequency profile for SyncE recovered clock.
                   Supported profiles are "25MHz"
       -pclk     : Enable or disable primary clock for PF or port,
                   overriding previous primary clock setting.
       -scl      : Enable or disable secondary clock for PF or port,
                   overriding previous secondary clock setting.

  Below command is used to query the SyncE parameters.

      niccli -i <target index> synce -get

       -get      : Get the synchronous ethernet frequency profile, primary and
                   secondary clock state.

Example :
     niccli -i 2 synce -get
     niccli -i 2 synce -set -freq 25MHz

tunnelcfg command
=====================
This command is used to query and configure the custom GRE tunnel offload.

Syntax:
     To get the state of GRE tunnel offload.
         niccli -i <target index> tunnelcfg -get

     To set the GRE tunnel offload.
         niccli -i <target index> tunnelcfg -set -state <0/1>
             -state       : This field is used to enable (1) or disable (0) the non udp port
	                    based GRE tunnel offload.


Example:
     niccli -i 5 tunnelcfg -get
     niccli -i 5  tunnelcfg -set -state 0

Portstate command
==================
This command is used to query or configure the port state
This command is supported only on Linux OS.

Syntax:
   To get the port state.
       niccli -i <target index> portstate -get

   To set the port state.
       niccli -i <target index> portstate -set -link <0/1/2>
                 0 - Down
                 1 - UP
                 2 - Toggle

Example:
     niccli -i 3 portstate -get
     niccli -i 3 portstate -set -link 0


Clearcounters command
=====================
This command is used to clear the port counters
This command is supported only on Linux OS.

Syntax:
     niccli -i <target index> clearcounters

Example:
     niccli -i 1 clearcounters

backup command
=============
Backup NVM contents to a file.
This command is only supported in UEFI platform.

Syntax:
     niccli -i <target index> backup [cfg]
                  cfg: Optional Parameter to backup NVM configuration.
/* End of file */
